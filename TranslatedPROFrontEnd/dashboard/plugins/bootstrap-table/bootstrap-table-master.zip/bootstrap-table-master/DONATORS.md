## List of donators

* Richard C Jordan - $35
* Janet Moery - $5
* Rene Halskov - $10
* Angel Arambula Garcia - $5
* David Graham - $5
* Paul Abbott - $20
* Philip Tepfer - $10
* Marcus Eddy - $5
* Keith Rockhold - $50
* Ramon Sosa Diaz - $10
* Goncalo Cordeiro - $25
* Marzena Wspanialy - $10
* Nicolas Pascual - $10
* Hassan Ejaz - $10
* Frank Hines - $100
